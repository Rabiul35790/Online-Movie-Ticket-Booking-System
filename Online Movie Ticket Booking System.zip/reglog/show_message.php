<?php
// Your database connection code
include "db_conn.php";



// Fetch unread messages from the database
$sql = "SELECT * FROM contact_tb WHERE status = 'unread' LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    $row = $result->fetch_assoc();
    echo "<div class='message'>";
    echo "<p><strong>Name:</strong> " . $row["name"] . "</p>";
    echo "<p><strong>Email:</strong> " . $row["email"] . "</p>";
    echo "<p><strong>Message:</strong> " . $row["message"] . "</p>";
    echo "</div>";

    // Update the status of the displayed message to 'read'
    $updateSql = "UPDATE contact_tb SET status = 'read' WHERE si = " . $row["si"];
    $conn->query($updateSql);
} else {
    echo "<p>No unread messages.</p>";
}

$conn->close();
?>