<!DOCTYPE html>
<html>
<head>
    <title>Image Upload Using PHP</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            padding: 20px;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
        }
        .upload-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 45%;
            margin-right: 20px;
        }
        .delete-section,
        .user-message-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: calc(55% - 20px); /* Width of right column - margin */
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="text"],
        input[type="file"],
        input[type="submit"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: darkblue;
            color: white;
            cursor: pointer;
        }
        .user-message-section button {
            background-color: darkblue;
            color: white;
            cursor: pointer;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="upload-section">
        <h1>Upload Movie</h1>
        <?php if (isset($_GET['error'])): ?>
            <p style="color: red;"><?php echo $_GET['error']; ?></p>
        <?php endif ?>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" name="my_image">
            <input type="text" name="movie_name" placeholder="Movie Name">
            <input type="text" name="details" placeholder="Details">
            <input type="text" name="movie_code" placeholder="Movie Code">
            <input type="text" name="booked" placeholder="Booked">
            <input type="submit" name="submit" value="Upload">
        </form>
    </div>
    <div class="delete-section">
        <h1>Delete Movie</h1>
        <form action="delete.php" method="post">
            <input type="text" name="delete_movie_name" placeholder="Enter Movie Name to Delete">
            <input type="submit" name="delete" value="Delete">
        </form>
    </div>
    <div class="user-message-section">
        <h1>User Message</h1>
        <?php include('show_message.php'); ?>
        <button id="okButton">Next</button>
    </div>

    <script>
        document.getElementById("okButton").addEventListener("click", function() {
        // Refresh the user message section upon clicking the "OK" button
        // You can use AJAX here to refresh without reloading the page
        location.reload();
        });
    </script>
</body>
</html>
