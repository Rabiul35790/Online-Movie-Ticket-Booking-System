// Function to show password requirements form
function showPasswordRequirements() {
  document.getElementById('requirements').style.display = 'block';
}

// Function to hide password requirements form
function hidePasswordRequirements() {
  const requirements = document.querySelectorAll('#requirements input[type="checkbox"]');
  let allRequirementsMet = true;

  requirements.forEach((checkbox) => {
    if (!checkbox.checked) {
      allRequirementsMet = false;
    }
  });

  if (allRequirementsMet) {
    document.getElementById('requirements').style.display = 'none';
  }
}

// Event listener for clicking on the password field
document.getElementById('f4').addEventListener('click', function() {
  showPasswordRequirements();
});

// Event listener for typing in the password field
document.getElementById('f4').addEventListener('input', function() {
  const password = this.value;

  const containsLowercase = /[a-z]/.test(password);
  document.getElementById('containsLowercase').checked = containsLowercase;

  const containsUppercase = /[A-Z]/.test(password);
  document.getElementById('containsUppercase').checked = containsUppercase;

  const containsNumber = /\d/.test(password);
  document.getElementById('containsNumber').checked = containsNumber;

  const containsSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(password);
  document.getElementById('containsSpecialChar').checked = containsSpecialChar;

  const atLeastEightCharacters = password.length <= 8;
  document.getElementById('atLeastEightCharacters').checked = atLeastEightCharacters;

  hidePasswordRequirements();
});

// Event listener for when the password field loses focus
document.getElementById('f4').addEventListener('blur', function() {
  hidePasswordRequirements();
});






  

  