<?php 
if (isset($_POST['delete']) && isset($_POST['delete_movie_name'])) {
    include "db_conn.php";

    $delete_movie_name = $_POST['delete_movie_name'];

    // Check if the movie exists in the images table
    $check_movie_query = "SELECT * FROM images WHERE movie_name='$delete_movie_name'";
    $check_movie_result = mysqli_query($conn, $check_movie_query);

    if(mysqli_num_rows($check_movie_result) > 0) {
        // Delete from Database - Table: images
        $sql_images = "DELETE FROM images WHERE movie_name='$delete_movie_name'";
        mysqli_query($conn, $sql_images);

        // Delete from Database - Table: chart
        $sql_chart = "DELETE FROM chart WHERE movie_name='$delete_movie_name'";
        mysqli_query($conn, $sql_chart);

        echo "<script>alert('Movie Deleted Successfully');</script>";
        echo "<script>window.location='index.php';</script>";
        exit();
    } else {
        echo "<script>alert('Movie does not exist');</script>";
        echo "<script>window.location='index.php';</script>";
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}
?>
