<?php include "db_conn.php"; ?>

<?php
session_start();

// Retrieve the booking code



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="book.css">
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="first">
      <div class="magic-text"><b>CineMagic</b></div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php" class = "logs">Ticket price</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>
        <div class="verh">
            <h3 class="another-text">Select Movie Version</h3>
        </div>
        <div class="ver">
            <div class="vera">
                <button type="button" class="button button1">2D</button>
            </div>
                
            <div class="verb">
                <button type="button" class="button" onclick="redirectToHome()">3D</button>
            </div>
        </div>
        <form class="box" method="post">
        <div class="second">
                <?php 
                // Array of colors
                $colors = array("white", "skyblue", "grey", "white");
                
                $sql = "SELECT * FROM images ORDER BY id DESC LIMIT 4"; // Fetches the latest four images
                $res = mysqli_query($conn, $sql);

                if (mysqli_num_rows($res) > 0) {
                    $colorIndex = 0; // Initialize color index
                    while ($images = mysqli_fetch_assoc($res)) { ?>
                        <div class="leftp" style="background-color: <?php echo $colors[$colorIndex]; ?>">
                            <b style="font-size:30px"><?php echo $images['movie_name']; ?></b>
                            <u style="font-size:14px"><?=$images['movie_code']?></u>
                            <p style="font-size: 25px">Premium: 500 Taka</p>
                            <p style="font-size: 25px">Regular: 350 Taka</p>
                        </div>
                    <?php 
                        $colorIndex++; // Move to the next color
                        // Reset color index if it exceeds the number of colors in the array
                        if ($colorIndex >= count($colors)) {
                            $colorIndex = 0;
                        }
                    }
                } ?>
            </div>
        </form>
    </div>
    <script>
        function redirectToHome() {
            // Redirect to the selver3d.php page
            window.location.href = 'selver3d1.php';
        }

    </script>
</body>
</html>
