
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="branch.css">
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="first">
    <div class="magic-text"><b>CineMagic</b></div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>
        <div class="verh">
            <h3 class = "another-text">Select Branch</h3>
        </div>
        <div class="ver">
            <div class="vera">
                <button type="button" class="button" onclick="redirectToselbranch1()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Banani CineMagic</button>
            </div>
                
            <div class="verb">
                <button type="button" class="button" onclick="redirectToselbranch2()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Purbachal CineMagic</button>
            </div>
        </div>
        <div class="ver">
            <div class="vera">
                <button type="button" class="button" onclick="redirectToselbranch3()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Mirpur-1 CineMagic</button>
            </div>
                
            <div class="verb">
                <button type="button" class="button" onclick="redirectToselbranch4()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Gulshan CineMagic</button>
            </div>
        </div>
        
    </div>
    <script>
        function redirectToselbranch1() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch1.php';
        }
        function redirectToselbranch2() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch2.php';
        }
        function redirectToselbranch3() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch3.php';
        }
        function redirectToselbranch4() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch4.php';
        }
    </script>
</body>
</html>
