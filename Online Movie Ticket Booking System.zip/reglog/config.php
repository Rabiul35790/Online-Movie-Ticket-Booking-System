<?php
require('stripe-php-master/init.php');

$Publishablekey =
"pk_test_51OTP4tD6qTMyeCUdk8wYrXC2lI6KmzRxKerDDHkJbPCKfi6te9CpCDLgegJbe9XauKM7yscXVlzyfOo9mm8rshEd00N7GK7nl2";

$Secretkey =
"sk_test_51OTP4tD6qTMyeCUdTWeaJgin1tA1TFmxrAP4LpusBzaLJvax6tMeG6GFBs1ZTxF9k5TLSIQsWfFxZoztcBfGrqSi00DI3n6kLC";

\stripe\stripe::setApiKey($Secretkey);
?>