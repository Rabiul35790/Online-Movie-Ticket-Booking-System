<?php include "db_conn.php"; ?>

<?php
session_start();

// Retrieve the booking code
if (isset($_SESSION['booking_code'])) {
    $booking_code = $_SESSION['booking_code'];
} else {
    $booking_code = generateRandomCode(6);
    
}

if (isset($_POST['login'])) {
            $selected_day = 'Thursday'; // Assuming the default day is Wednesday for this example
            $selected_time = '11:00 AM'; // Assuming the default time is 11:00 AM for this example
            $selected_seat_type = $_POST['seat_type'] ?? '';
            $selected_quantity = $_POST['count'] ?? 0;
            $selected_date = $_SESSION['date2'] ?? date('Y-m-d'); // Get 'date1' value
        if (!empty($selected_seat_type)) {
            // Insert data into other_tb table including the date1 value
            $sql_insert_other_tb = "INSERT INTO other_tb (day, time, seat_type, quantity, date, booking_code) 
                                    VALUES ('$selected_day', '$selected_time', '$selected_seat_type', '$selected_quantity', '$selected_date', '$booking_code')";
            mysqli_query($conn, $sql_insert_other_tb);

            // Find movie_code corresponding to the booking_code in version_tb
            $sql_select_movie_code = "SELECT movie_code FROM version_tb WHERE booking_code = '$booking_code'";
            $result = mysqli_query($conn, $sql_select_movie_code);

            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $movie_code = $row['movie_code'];

                // Update the booked attribute in the chart table
                $sql_update_chart = "UPDATE chart SET booked = booked + '$selected_quantity' WHERE movie_code = '$movie_code'";
                mysqli_query($conn, $sql_update_chart);
            }

            header("Location: selseat.php");
            exit();
        } else {

            echo '<script>alert("Select a seat type")</script>';
        }
    
}
$date1 = $_SESSION['date1'] ?? date('Y-m-d'); // Default to current date if not set
$date2 = $_SESSION['date2'] ?? date('Y-m-d');
$date3 = $_SESSION['date3'] ?? date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="other.css">
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="first">
    <div class="magic-text"><b>CineMagic</b></div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>
        <div class="verh">
            <h3>Select Date</h3>
        </div>
        <div class="ver" style="padding-left:60px;">
            <div class="vera">
                <div class="verk" style="font-size:1rem; color:#F0E68C; width:100%;height:30px; ">
                    <h2 style="padding-left:20px;">Select Show Time</h2>
                    <div class="ver">
                        <div class="verb">
                            <button style="height:60px; width:130px; padding-bottom:30px; border-radius: 20px;" type="button" class="button button1" onclick="redirectToselother2a()"><h4>11:00 AM</h4></button>
                        </div>
                        <div class="verb" >
                            <button style="height:60px; width:130px; padding-bottom:30px; border-radius: 20px;" type="button" class="button" onclick="redirectToselother2b()"><h4>04:00 PM</h4></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vera" style="margin-left:300px">
            <button type="button" class="button" onclick="redirectToselother1()"><h3>Wednesday</h3><?php echo date('F j', strtotime($date1)); ?></button>
            </div>    
            <div class="vera">
                <button type="button" class="button button1" onclick="redirectToselother2()"><h3>Thursday</h3><?php echo date('F j', strtotime($date2)); ?></button>
            </div>
            <div class="vera" style="padding-right:100px">
                <button type="button" class="button" onclick="redirectToselother3()"><h3>Friday</h3><?php echo date('F j', strtotime($date3)); ?></button>
            </div>
        </div>

        <form class="box" method="post">
            <div class="ver" style="height: 120px; padding-left:60px;">
                <div class="vera">
                    
                </div>

                <div class="vera">
                    <div class="verk" style="font-size:25px; color:#F0E68C; width:100%;height:30px; ">
                        <b>Select Seat Type</b>
                        <div class="ver">
                            <div class="verb">
                                <input type="radio" id="premium" name="seat_type" value="Premium">
                                <label for="premium"><b>Premium</b></label><br>
                                <input type="radio" id="regular" name="seat_type" value="Regular">
                                <label for="regular"><b>Regular</b></label><br> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="vera">
                </div>

                <div class="vera">
                    <div class="verk" style="font-size:25px; width:100%;height:30px; ">
                        <b style="font-size: 20px; padding-left:70px">Ticket Quantity</b><br>
                        <div class="ver">
                            <div class="verb">
                                <button style="margin-left: 70px; background-color: transparent; text-align: center; color: black; height: 35px; width: 30px; font-size: 30px;" type="button" onclick="decrement()">-</button>
                            </div>
                            <div class="verb" >
                                <input id="quantity" style="margin-left: 0px; background-color: white; opacity:0.4; text-align: center; color: black; height: 35px; width: 90px; font-size: 30px;" type="text" name="count" value="1">
                            </div>
                            <div class="verb">
                                <button style="margin-left: 0px; background-color: transparent; text-align: center; color: black; height: 35px; width: 30px; font-size: 30px;" type="button" onclick="increment()">+</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <input type="submit" name="login" value="Next">
        </form>
    </div>
    <script>
        function redirectToselother1() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother1a.php';
        }
        function redirectToselother2() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother2a.php';
        }
        function redirectToselother3() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother3a.php';
        }
        function redirectToselother2b() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother2b.php';
        }
        function decrement() {
            var quantity = document.getElementById('quantity');
            if (quantity.value > 1) {
                quantity.value--;
            }
        }

        function increment() {
            var quantity = document.getElementById('quantity');
            quantity.value++;
        }
    </script>
</body>
</html>
