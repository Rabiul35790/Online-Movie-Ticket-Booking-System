<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login Page</title>
</head>
<body class="sbd">
    <div class="nav">
        <b>CineMagic</b>
    </div>
    
    <div class="navbar"> 
        <div class="menu"> 
            <a href="login.php">Home</a> 
            <a href="login.php">Show Time</a> 
            <a href="login.php">Movie List</a> 
            <a href="login.php">Ticket price</a> 
            <a href="login.php">About Us</a>
            <a href="login.php">Contact</a>
            <a href="signup.php">Signup</a>
            <a href="login.php">Login</a>
            <a class="logs" href="admin.php">Admin</a>
        </div>
    </div>
    
    <?php 
    session_start();

    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Check if the username and password match the hardcoded credentials
        if ($username === 'admin123' && $password === 'adminadmin#') {
            echo "<script>window.location = 'index.php';</script>";
            exit; // Exit to prevent further execution
        } else {
            echo "<script>alert('Invalid credentials.');</script>";
        }
    }
    ?>
    
    <form class="boxs" action="" method="post">
        <h1>Admin Login</h1>
        <div class="column">
            <div class="input-sdata">
                <input type="text" required name="username">
                <div class="underline"></div>
                <label>Username</label>
            </div>
            <div class="input-sdata">
                <input type="password" required name="password">
                <div class="underline"></div>
                <label>Password</label>
            </div>
        </div>
        <input type="submit" name="login" value="Login"><br/>
    </form>

</body>
</html>
