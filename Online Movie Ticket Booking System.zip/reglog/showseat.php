<?php include "db_conn.php"; ?>

<?php
session_start();

// Retrieve the booking code
if (isset($_SESSION['booking_code'])) {
    $booking_code = $_SESSION['booking_code'];
} else {
    $booking_code = generateRandomCode(6);
}

// Fetch selected seats for the current booking code from the database
$selected_seats_query = "SELECT seat_name FROM all_tb WHERE booking_code = '$booking_code'";
$selected_seats_result = mysqli_query($conn, $selected_seats_query);

$selected_seats = [];
if ($selected_seats_result && mysqli_num_rows($selected_seats_result) > 0) {
    while ($row = mysqli_fetch_assoc($selected_seats_result)) {
        $selected_seats[] = $row['seat_name'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="seat.css">
    <title>Movie Ticket Sales</title>
    <style>
        /* Your CSS styles */
        
        /* Style for next button */
        .next-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="first">
        <div class="magic-text"><b>CineMagic</b></div>
            <div class="navbar">
                <div class="menu">
                    <a href="home.php">Home</a>
                    <a href="showtimes.php">Show Time</a>
                    <a href="movielist.php">Movie List</a>
                    <a href="selver1.php">Ticket price</a>
                    <a href="about.php">About Us</a>
                    <a href="contact.php">Contact</a>
                    
                </div>
                <a href="login.php" class="logout">Logout</a>
            </div>
            <!-- Form with action set to allinfo.php -->
            <form method="post" action="allinfo.php">
                <div class="input-row">
                    <!-- Your input elements if any -->
                </div>
                <div class="content">
                    <h4 style="text-align:center; font-size:3rem;margin-top:10%;">Selected Seats are</h4>
                    <!-- Display the selected seats here -->
                    <?php if (!empty($selected_seats)) : ?>
                        <ul style="margin-left:500px; font-size:3rem; ">
                            <?php foreach ($selected_seats as $seat) : ?>
                                <li><?php echo $seat; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p>No seats selected.</p>
                    <?php endif; ?>
                </div>
                <div class="legend" style="font-size: 30px">
                    <!-- Your legend content if any -->
                </div>
                <!-- "Next" button placed at the bottom right corner of the form -->
                <button type="submit" class="next-button">Next</button>
            </form>
        </div>
    </div>
</body>
</html>
