<?php
$con = mysqli_connect("localhost", "root", "", "test_db");
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM chart ORDER BY si DESC LIMIT 20";
$result = mysqli_query($con, $sql);
if (!$result) {
  die("Error fetching recent records: " . mysqli_error($con));
}

$sql_top = "SELECT * FROM (SELECT * FROM chart ORDER BY si DESC LIMIT 20) AS recent ORDER BY booked DESC LIMIT 4";
$result_top = mysqli_query($con, $sql_top);
if (!$result_top) {
  die("Error fetching top movies: " . mysqli_error($con));
}

// Extracting top 4 movies data
$data_top_movies = [];
while ($row_top = mysqli_fetch_assoc($result_top)) {
  $data_top_movies[] = ['Movie' => $row_top['movie_name'], 'Booked' => (int)$row_top['booked']];
}

if (isset($_GET['search'])) {
  $search = $_GET['search'];

  $sql = "SELECT * FROM images WHERE movie_name LIKE '%$search%'";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
          echo "<div>";
          echo "<p>{$row['movie_name']}</p>";
          echo "<img src='uploads/{$row['image_url']}' width='220' height='300'>";
          echo "</div>";
      }
  } else {
      echo "No results found";
  }
} 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Movie', 'Booked'],
        <?php
          foreach ($data_top_movies as $movie) {
            echo "['" . $movie['Movie'] . "'," . $movie['Booked'] . "],";
          }
        ?>
      ]);

      var options = {
        title: 'Percentage of Movie Ticket Sales',
        backgroundColor: 'transparent',
        chartArea: {
          left: 100,
          top: 30,
          width: '90%',
          height: '88%'
        },
        legend: 'none' // Hide the legend
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart'));
      chart.draw(data, options);
    }
  </script>

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="home.css">

  <title>Movie Ticket Sales</title>
  <style>
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }

        .search-form {
            margin-top: 10px;
            text-align: right;
            padding-right: 20px;
        }

        .search-form input[type="text"],
        .search-form button {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 5px;
        }

        .search-form button {
            background-color: #f44336;
            color: white;
            border: none;
            cursor: pointer;
        }

        .title-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
</head>
<body class="hom">
  <div class="first">
  <div class="title-section">
        <div class="magic-text"><b>CineMagic</b></div>
            <div class="search-form">
                <form action="search.php" method="GET">
                    <input type="text" placeholder="Search..." name="search">
                    <button type="submit">Search</button>
                </form>
            </div>
        </div>
        <div class="navbar">
        <div class="menu">
          <a class="logs" href="home.php">Home</a>
          <a href="showtimes.php">Show Time</a>
          <a href="movielist.php">Movie List</a>
          <a href="selver1.php">Ticket price</a>
          <a href="about.php">About Us</a>
          <a href="contact.php">Contact</a>
        </div>
        <a href="login.php" class="logout">Logout</a> <!-- Move logout link to the right -->
      </div>
    <h1 class="hea animate">CineMagic</h1>
    <div class="second">
      <div class="leftp">
        <div id="piechart"></div>
      </div>
      
      <div class="rightp">
        <h2 class="fou">Trending</h2>
        <ul type="square" class="listi">
          <?php
            $colors = ['#3366cc', '#dc3912', '#ff9900', '#109618']; // Update with actual pie chart colors
            foreach ($data_top_movies as $i => $movie) {
              echo '<li style="color:' . $colors[$i] . '">' . $movie['Movie'] . '</li>';
            }
          ?>
        </ul>
      </div>
    </div>
  </div>
  <footer>
        &copy; 2024 CineMagic Movie Ticket Booking System. All Rights Reserved.
    </footer>
</body>
</html>
