<?php
ob_start(); // Start output buffering

include "db_conn.php";
require('config.php');

session_start();

// Retrieve the booking code
if (isset($_SESSION['booking_code'])) {
    $booking_code = $_SESSION['booking_code'];
} else {
    $booking_code = generateRandomCode(6);
}
$amount_quiry = "SELECT amount FROM amount WHERE booking_code = '$booking_code'";
$amount_result = mysqli_query($conn, $amount_quiry);
if($amount_result && mysqli_num_rows($amount_result) > 0){
    $row = mysqli_fetch_assoc($amount_result);
    $amount = $row['amount'];
}
if(isset($_POST['stripeToken'])){
(int)$amount = (int)$amount * 100;
\Stripe\Stripe::setVerifySslCerts (false);
$token=$_POST['stripeToken'];
$data=\Stripe\Charge::create(array(
"amount"=>(int)$amount,
"currency"=>"bdt",
"description"=>"Book your seats",
"source"=>$token,
));
}

$seats_query = "SELECT branch, date, time, seat_type, seat_name, movie_code FROM all_tb WHERE booking_code = '$booking_code'";
$seats_result = mysqli_query($conn, $seats_query);

$quantity_quiry = "SELECT quantity FROM other_tb WHERE booking_code = '$booking_code'";
$quantity_result = mysqli_query($conn, $quantity_quiry);

if ($seats_result && mysqli_num_rows($seats_result) > 0 && $quantity_result && mysqli_num_rows($quantity_result) > 0) {
    $row = mysqli_fetch_assoc($seats_result);
    $row1 = mysqli_fetch_assoc($quantity_result);
    $branch = $row['branch'];
    $date = $row['date'];
    $time = $row['time'];
    $seat_type = $row['seat_type'];
    $seat_name = $row['seat_name'];
    $movie_code = $row['movie_code'];
    $quantity = $row1['quantity'];

    // Fetch movie name from the 'images' table based on the movie_code
    $movie_query = "SELECT movie_name FROM images WHERE movie_code = '$movie_code'";
    $movie_result = mysqli_query($conn, $movie_query);

    if ($movie_result && mysqli_num_rows($movie_result) > 0) {
        $movie_row = mysqli_fetch_assoc($movie_result);
        $movie_name = $movie_row['movie_name'];
    }
}

    $for_amount = "SELECT seat_type, version FROM all_tb WHERE booking_code = '$booking_code'";
    $amount_result = mysqli_query($conn, $for_amount);
    if($amount_result && mysqli_num_rows($amount_result) > 0){
        $row2 = mysqli_fetch_assoc($amount_result);
        $seat_type1 = $row2['seat_type'];
        $version = $row2['version'];
    }

    if (isset($_POST['download'])) {
        require_once('tcpdf/tcpdf.php'); // Replace 'tcpdf/tcpdf.php' with the path to your TCPDF library
        
        // Create a new PDF document
        $pdf = new TCPDF();
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Your Name');
        $pdf->SetTitle('Ticket Information');
        $pdf->SetSubject('Ticket Details');
        $pdf->SetKeywords('Ticket, Movie, Details');
    
        // Add a page to the PDF
        $pdf->AddPage();
    
        // Write content to the PDF
        // Write content to the PDF
                $content = "
                <div style='text-align:center; font-size:24px;'><b>CineMagic</b></div>
                <div style='text-align:center;'>Ticket Information<br><br>
                <b>Movie Name:</b> " . (isset($movie_name) ? $movie_name : '') . "<br><br>
                <b>Location:</b> " . (isset($branch) ? $branch : '') . " CineMagic<br><br>
                <b>Date:</b> " . (isset($date) ? $date : '') . "<br><br>
                <b>Time:</b> " . (isset($time) ? $time : '') . "<br><br>
                <b>Version:</b> " . (isset($version) ? $version : '') . "<br><br>
                <b>Seat Type:</b> " . (isset($seat_type) ? $seat_type : '') . "<br><br>
                <b>Seat Quantity:</b> " . (isset($quantity) ? $quantity : '') . "<br><br>
                <b>Seat Number:</b> " . (isset($seat_name) ? $seat_name : '') . "<br><br></div>
                ";

                $pdf->writeHTML($content, true, false, true, false, '');


    
        // Set the file name and force download
        $file_name = 'Ticket_Info_' . date('YmdHis') . '.pdf';
        $pdf->Output($file_name, 'D');
        exit;
    }

    
    if (isset($_POST['backhome'])) {
        header("Location: home.php");
        exit;
    }

    ob_end_clean();
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="info.css">
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="container">
        <div class="first">
        <div class="magic-text"><b>CineMagic</b></div>
            <div class="navbar">
                <div class="menu">
                    <a href="home.php">Home</a>
                    <a href="showtimes.php">Show Time</a>
                    <a href="movielist.php">Movie List</a>
                    <a href="selver1.php">Ticket price</a>
                    <a href="about.php">About Us</a>
                    <a href="contact.php">Contact</a>
                    
                </div>
                <a href="login.php" class="logout">Logout</a>
            </div>
            <div>
                <p style = "font-size:20px; text-align:center;">Payment Successful..........</p>
            </div>
            <form method="post" action="submit.php">
                <div class="details">
                    <b>Movie Name:</b> <?php echo isset($movie_name) ? $movie_name : ''; ?><br><br>
                    <b>Location:</b> <?php echo isset($branch) ? $branch : ''; ?> CineMagic<br><br>
                    <b>Date:</b> <?php echo isset($date) ? $date : ''; ?><br><br>
                    <b>Time:</b> <?php echo isset($time) ? $time : ''; ?><br><br>
                    <b>version:</b> <?php echo isset($version) ? $version : ''; ?><br><br>
                    <b>Seat Type:</b> <?php echo isset($seat_type) ? $seat_type : ''; ?><br><br>
                    <b>Seat Quantity:</b> <?php echo isset($quantity) ? $quantity : ''; ?><br><br>
                    <b>Seat Number:</b> <?php echo isset($seat_name) ? $seat_name : ''; ?><br><br>
                    <button type="submit" class="download-button" name = "download">Download</button>
                    <button type="submit" class="next-button" name = "backhome">Back to home</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>