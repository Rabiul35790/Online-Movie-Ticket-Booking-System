<?php include "db_conn.php"; ?>

<?php
session_start();

// Retrieve the booking code
if (isset($_SESSION['booking_code'])) {
    $booking_code = $_SESSION['booking_code'];
} else {
    $booking_code = generateRandomCode(6);
}

// Seat arrangement logic
$show_seats = false; // Initialize to hide seats

if (isset($_POST['selectButton'])) {
    $show_seats = true; // Set to show seats
    // Get seat type from the 'other_tab' table based on booking code
    $query = "SELECT seat_type FROM other_tb WHERE booking_code = '$booking_code'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $seat_type = $row['seat_type'];

        // Block seats based on seat type
        if ($seat_type === 'Regular') {
            $blocked_seats = ['D0', 'E0', 'F0', 'D1', 'E1', 'F1', 'D2', 'E2', 'F2', 'D3', 'E3', 'F3', 'D4', 'E4', 'F4', 'D5', 'E5', 'F5', 'D6', 'E6', 'F6', 'D7', 'E7', 'F7', 'D8', 'E8', 'F8', 'D9', 'E9', 'F9'];
        } elseif ($seat_type === 'Premium') {
            $blocked_seats = ['A0', 'B0', 'C0', 'A1', 'B1', 'C1', 'A2', 'B2', 'C2', 'A3', 'B3', 'C3', 'A4', 'B4', 'C4', 'A5', 'B5', 'C5', 'A6', 'B6', 'C6', 'A7', 'B7', 'C7', 'A8', 'B8', 'C8', 'A9', 'B9', 'C9'];
        }

        // Modify seat display based on blocked seats
        foreach ($blocked_seats as $blocked_seat) {
            unset($_POST[$blocked_seat]); // Unset the POST value to disable selection
        }
    }
    $get_this = "SELECT other_tb.date, other_tb.time, other_tb.seat_type, branch_tb.branch, version_tb.movie_code, version_tb.version
                    FROM other_tb
                    INNER JOIN branch_tb ON other_tb.booking_code = branch_tb.booking_code
                    INNER JOIN version_tb ON other_tb.booking_code = version_tb.booking_code
                    WHERE other_tb.booking_code = '$booking_code'";
    $get_this_result = mysqli_query($conn, $get_this);

    if($get_this_result){
        $row11 = mysqli_fetch_assoc($get_this_result);
        $date = $row11['date'];
        $time = $row11['time'];
        $seat_type = $row11['seat_type'];
        $branch = $row11['branch'];
        $movie_code = $row11['movie_code'];
        $version = $row11['version'];
    } else {
        echo '<script>alert("Unable to collect data.");</script>';
    }
    $query_booked_seats = "SELECT seat_name FROM all_tb
                            WHERE movie_code = '$movie_code'
                            AND version = '$version'
                            AND branch = '$branch'
                            AND date = '$date'
                            AND time = '$time'
                            AND seat_type = '$seat_type'";
    $result_booked_seats = mysqli_query($conn, $query_booked_seats);

    if ($result_booked_seats) {
        $booked_seats = [];

        while ($row_booked_seats = mysqli_fetch_assoc($result_booked_seats)) {
            $seat_names = $row_booked_seats['seat_name'];
            $booked_seat_names = explode(',', $seat_names);

            // Add the booked seats to the array
            $booked_seats = array_merge($booked_seats, $booked_seat_names);
        }

        // Modify seat display based on booked seats
        foreach ($booked_seats as $booked_seat) {
            unset($_POST[$booked_seat]); // Unset the POST value to disable selection
        }
    } else {
        echo '<script>alert("Unable to fetch booked seats from all_tb.");</script>';
    }
}


if (isset($_POST['confirmButton'])) {
    // Retrieve quantity from the database based on the booking code
    $query = "SELECT quantity FROM other_tb WHERE booking_code = '$booking_code'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row5 = mysqli_fetch_assoc($result);
        $quantity_from_db = $row5['quantity'];

        $checked_seats_count = 0;

        // Loop through seat checkboxes to count checked ones
        $rows = range('A', 'F');
        foreach ($rows as $index => $row) {
            for ($j = 0; $j < 10; $j++) {
                $seat_id = $row . $j;
                // Check if the checkbox is checked
                if (isset($_POST[$seat_id]) && $_POST[$seat_id] === 'on') {
                    $checked_seats_count++;
                }
            }
        }

        if ($checked_seats_count === (int)$quantity_from_db) {
            // Gather selected seats' names
            $selected_seats = [];
            $rows = range('A', 'F');
            foreach ($rows as $index => $row) {
                for ($j = 0; $j < 10; $j++) {
                    $seat_id = $row . $j;
                    if (isset($_POST[$seat_id]) && $_POST[$seat_id] === 'on') {
                        $selected_seats[] = $seat_id;
                    }
                }
            }

            // Fetch movie details from other_tb
            $get_this = "SELECT other_tb.date, other_tb.time, other_tb.seat_type, branch_tb.branch, version_tb.movie_code, version_tb.version
                            FROM other_tb
                            INNER JOIN branch_tb ON other_tb.booking_code = branch_tb.booking_code
                            INNER JOIN version_tb ON other_tb.booking_code = version_tb.booking_code
                            WHERE other_tb.booking_code = '$booking_code'";
            $get_this_result = mysqli_query($conn, $get_this);

            if ($get_this_result) {
                $row11 = mysqli_fetch_assoc($get_this_result);
                $date = $row11['date'];
                $time = $row11['time'];
                $seat_type = $row11['seat_type'];
                $branch = $row11['branch'];
                $movie_code = $row11['movie_code'];
                $version = $row11['version'];

                // Update 'all_tb' table with confirmed seat information
                $insert_query = "INSERT INTO all_tb (movie_code, booking_code, version, branch, date, time, seat_type, seat_name) 
                                VALUES ('$movie_code', '$booking_code', '$version', '$branch', '$date', '$time', '$seat_type', '" . implode(',', $selected_seats) . "')";

                if (mysqli_query($conn, $insert_query)) {
                    // Confirmation message and redirect
                    echo '<script>alert("Seats confirmed!");</script>';
                    header("Location: showseat.php");
                    exit();
                } else {
                    echo '<script>alert("Error updating all_tb table.");</script>';
                }
            } else {
                echo '<script>alert("Unable to collect data from other_tb.");</script>';
            }
        } else {
            echo '<script>alert("Please select exactly ' . $quantity_from_db . ' seat(s).");</script>';
        }
    } else {
        echo '<script>alert("Cannot fetch quantity value.");</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="seat.css">
    <title>Movie Ticket Sales</title>
    <style>
        

        .row {
            display: flex;
            justify-content: space-around;
            margin-bottom: 2px;
        }

        /* Modified seat styles */
        .seat {
            width: 35px;
            height: 35px;
            background-color: #ccc;
            margin: 2px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            
        }

        .seat input[type="checkbox"] {
            display: none; /* Hide the actual checkboxes */
        }

        .seat input[type="checkbox"]:checked + label {
            background-color: blue; /* Change color when checked */
        }

        .seat label {
            width: 100%;
            height: 100%;
            display: block;
            cursor: pointer;
            text-align: center;
            justify-content: center;
            margin-top:20px;
            font-family: Monospace;
            font-weight: bold;
            font-style: normal;
        }

        /* Hide input field if $hide_input is true */
        .hideInput {
            display: <?php echo $hide_input ? 'none' : 'block'; ?>;
        }

        /* Style for input and button in the same row */
        .input-row {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .input-row input[type="text"] {
            padding: 8px;
            margin-right: 10px;
        }

        .input-row button {
            padding: 8px 16px;
            cursor: pointer;
        }

        /* Style for next button */
        

        /* Seat type legend */
        .legend {
            margin-top: 10px;
            display: flex;
            justify-content: center;
        }

        .legend div {
            margin-right: 10px;
        }

        .regular {
            background-color: #17b7f2; 
           
        }

        .premium {
            background-color: #83f77f; /* Premium seat color */
        }
        /* CSS for seat arrangement */
        .container {
            position: relative;
        }

        .content {
            display: <?php echo $show_seats ? 'flex' : 'none'; ?>; /* Hide seats initially */
            flex-direction: column;
            font-size: 10px;
            margin-top: 20px;
        }

        /* ... (rest of the styles remain the same) ... */

        /* Style for next button */
        .next-button {
            position: absolute;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .seat.booked label {
        background-color: blue; /* Color for booked seats */
    }

    /* Newly selected seats styling */
    .seat input[type="checkbox"]:checked + label:not([disabled]) {
        background-color: #32CD32; /* Color for newly selected seats */
    }
    </style>
</head>
<body>
    <div class="container">
        <div class="first">
        <div class="magic-text"><b>CineMagic</b></div>
            <div class="navbar">
                <div class="menu">
                    <a href="home.php">Home</a>
                    <a href="showtimes.php">Show Time</a>
                    <a href="movielist.php">Movie List</a>
                    <a href="selver1.php">Ticket price</a>
                    <a href="about.php">About Us</a>
                    <a href="contact.php">Contact</a>
                    
                </div>
                <a href="login.php" class="logout">Logout</a>
            </div>
            <div class="input-row">
                <form method="post" action="">
                    <?php if (!$show_seats) : ?>
                        <button class="selectButton" name="selectButton">Select Seat</button>
                    <?php else : ?>
                        <button class="selectButton" name="confirmButton">Confirm</button>
                        <b style = "background-color:blue;font-size:15px;margin-left:600px;color:white; font-style:normal">**booked</b>
                        <b style = "font-size:15px;font-style:normal; border:2px dotted black">&nbsp;&nbsp; **A,B,C Rows(Regular)</b>
                        <b style = "font-size:15px;font-style:normal; border:2px dotted black">&nbsp;&nbsp; **D,E,F Rows(Premium)</b>
                    <?php endif; ?>
                
            </div>
            <div class="content">
    <?php if ($show_seats) : ?>
        <?php $rows = range('A', 'F'); ?>
        <?php foreach ($rows as $index => $row) : ?>
            <?php
                $row_color_class = ($seat_type === 'Regular' && $index >= 3) || ($seat_type === 'Premium' && $index < 3) ? 'premium' : 'regular';
            ?>
            <div class="row <?php echo $row_color_class; ?>">
                <?php for ($j = 0; $j < 10; $j++) : ?>
                    <?php
                        $seat_id = $row . $j;
                        $is_booked_seat = in_array($seat_id, $booked_seats);
                        $is_selected_seat = isset($_POST[$seat_id]) && $_POST[$seat_id] === 'on';
                        $is_disabled_seat = ($seat_type === 'Regular' && $index >= 3) || ($seat_type === 'Premium' && $index < 3);

                        // Determine classes for seat styles
                        $seat_classes = '';
                        if ($is_booked_seat || $is_disabled_seat) {
                            $seat_classes .= 'blocked';
                        }
                        if ($is_selected_seat) {
                            $seat_classes .= ' selected';
                        }
                    ?>
                    <div class="seat <?php echo $seat_classes; ?>">
                        <!-- Ensure the name attribute is properly set for the checkboxes -->
                        <input type="checkbox" id="<?php echo $seat_id; ?>" name="<?php echo $seat_id; ?>" <?php echo $is_booked_seat || $is_disabled_seat ? 'disabled' : ''; ?> />
                        <label for="<?php echo $seat_id; ?>" <?php echo $is_booked_seat || $is_disabled_seat ? 'disabled' : ''; ?>><?php echo $seat_id; ?></label>
                    </div>
                <?php endfor; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

            
        </div>
        
        </form>
        </div>
    </div>
    <script>
    // JavaScript to disable booked seats
    const bookedSeats = <?php echo json_encode($booked_seats); ?>;
    bookedSeats.forEach(seat => {
        const seatCheckbox = document.getElementById(seat);
        if (seatCheckbox) {
            seatCheckbox.disabled = true;
            seatCheckbox.checked = true; // Checked booked seats for clarity
        }
    });

        const unselectedSeats = <?php echo json_encode($blocked_seats); ?>;
        unselectedSeats.forEach(seat => {
            const seatCheckbox = document.getElementById(seat);
            if (seatCheckbox) {
                seatCheckbox.disabled = true;
            }
        });
</script>
</body>
</html>
