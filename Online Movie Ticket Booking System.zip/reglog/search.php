<?php include "db_conn.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background-color: wheat;
        }
        .title-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px; /* Adjust space between title section and images */
        }

        .back-button {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 8px 16px;
            border-radius: 5px;
            font-style: normal;
            background-color: green; /* Color for the button */
            font-size: 15px;
        }

        .image-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 10px; /* Adjust space between title section and images */
        }

        .image-item {
            margin: 20px;
            text-align: center;
            position: relative; /* Set position relative for the container */
        }

        .image-item p {
            font-size: 20px;
            font-weight: bold;
        }

        .buy-button {
            position: absolute;
            bottom: 90px; /* Adjust the distance from the bottom */
            left: 50%; /* Align the button in the center */
            transform: translateX(-50%);
            text-align: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 8px 16px;
            border-radius: 5px;
            font-style: normal;
            background-color: blue; /* Color for the button */
            font-size: 15px;
        }
        .search-form {
            margin-top: 10px;
            text-align: right;
            padding-right: 20px;
        }

        .search-form input[type="text"],
        .search-form button {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 5px;
        }

        .search-form button {
            background-color: #f44336;
            color: white;
            border: none;
            cursor: pointer;
        }
        
        .left-corner {
            position: absolute;
            top: 10px;
            left: 10px;
        }
    </style>
</head>
<body>
<div class="title-section">
    <a href="home.php" class="back-button">Back to Home&nbsp;&nbsp;<====</a>
        <div class="search-form">
            <form action="" method="GET">
                <input type="text" placeholder="Search..." name="search">
                <button type="submit">Search</button>
            </form>
        </div>
    </div>
    <div class="image-container">
    <?php
session_start();

function generateRandomCode($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}

if (isset($_GET['generate_code'])) {
    $booking_code = generateRandomCode(6);
    $_SESSION['booking_code'] = $booking_code;

    // Redirect to selver.php with the generated booking code as a URL parameter
    header("Location: selver.php?booking_code=$booking_code");
    exit();
}

if (isset($_GET['search'])) {
    $search = $_GET['search'];

    $sql = "SELECT * FROM images WHERE movie_name LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div>";
            echo "<p>{$row['movie_name']}</p>";
            echo "<img src='uploads/{$row['image_url']}' width='220' height='300'>";
            echo "</div>";
            
        }
    } else {
        echo "No results found";
    }
} 
?>
</div>
<a href="search.php?generate_code=true" class="buy-button left-button">Buy Ticket</a>

</body>
</html>


