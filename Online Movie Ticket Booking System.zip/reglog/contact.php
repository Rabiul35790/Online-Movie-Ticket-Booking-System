<?php
include "db_conn.php"; // Include your database connection file here

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Check if all fields are not empty before inserting data
    if (!empty($name) && !empty($email) && !empty($message)) {
        // Inserting data into the database
        $sql = "INSERT INTO contact_tb (name, email, message, status) VALUES ('$name', '$email', '$message', 'unread')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Message send Successfully');</script>";
            echo "<script>window.location='contact.php';</script>";
            exit();
        } else {
            // If an error occurs during insertion, display an error message
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo '<script>alert("Please fill in all the fields.");</script>';
    }

    mysqli_close($conn); // Close the database connection
}

// Add an alert message for successful submission

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="contact.css">
    <title>Contact Us - Movie Ticket Sales</title>
    <!-- Add inline styles if needed -->
    <style>
        /* Your existing styles (if any) */
    </style>
</head>
<body>
    <div class="first">
        <div class="title-section">
        <div class="magic-text"><b>CineMagic</b></div>
        </div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a href="about.php">About Us</a>
                <a class="logs" href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>

        <!-- Contact information and form -->
        <div class="second">
            <main>
                <section class="contact-section">
                    <h1>Contact Us</h1>
                    <p>We'd love to hear from you!</p>

                    <div class="contact-info">
                        <h2>Contact Information</h2>
                        <p><strong>Address:</strong> 123 Movie Avenue, Dhaka, Bangladesh</p>
                        <p><strong>Email:</strong> contact@cinemagic.com</p>
                        <p><strong>Phone:</strong> +88000000000000</p>
                    </div>

                    <div class="contact-form">
                        <h2>Send us a Message</h2>
                        <form action="contact.php" method="POST">
                            <label for="name">Name:</label>
                            <input type="text" id="name" name="name" required>

                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" required>

                            <label for="message">Message:</label>
                            <textarea id="message" name="message" required></textarea>

                            <button type="submit">Submit</button>
                        </form>
                    </div>
                </section>
            </main>
        </div>
    </div>
    <footer>
        &copy; 2024 CineMagic Movie Ticket Booking System. All Rights Reserved.
    </footer>
</body>
</html>