<?php
session_start();

// Retrieve dates from session variables
$date1 = $_SESSION['date1'] ?? date('Y-m-d'); // Default to current date if not set
$date2 = $_SESSION['date2'] ?? date('Y-m-d');
$date3 = $_SESSION['date3'] ?? date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    echo '<script>alert("All options must be required")</script>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="other.css">
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="first">
    <div class="magic-text"><b>CineMagic</b></div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>
        <div class="verh">
            <h3>Select Date</h3>
        </div>
        <div class="ver" style="padding-left:60px;">
            <div class="vera">
                <div class="verk" style="font-size:1rem; width:100%;height:30px; ">
                    <h2 style="padding-left:20px;">Select Show Time</h2>
                    <div class="ver">
                        <div class="verb">
                            <button style="height:60px; width:130px; padding-bottom:30px; border-radius: 20px;" type="button" class="button" onclick="redirectToselother2a()"><h4>11:00 AM</h4></button>
                        </div>
                        <div class="verb" >
                            <button style="height:60px; width:130px; padding-bottom:30px; border-radius: 20px;" type="button" class="button" onclick="redirectToselother2b()"><h4>04:00 PM</h4></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vera" style="margin-left:300px">
            <button type="button" class="button" onclick="redirectToselother1()"><h3>Wednesday</h3><?php echo date('F j', strtotime($date1)); ?></button>
            </div>    
            <div class="vera">
                <button type="button" class="button button1" onclick="redirectToselother2()"><h3>Thursday</h3><?php echo date('F j', strtotime($date2)); ?></button>
            </div>
            <div class="vera" style="padding-right:100px">
                <button type="button" class="button" onclick="redirectToselother3()"><h3>Friday</h3><?php echo date('F j', strtotime($date3)); ?></button>
            </div>
        </div>

        <form class="box" method="post">
            <div class="ver" style="height: 120px; padding-left:60px;">
                <div class="vera">
                    
                </div>

                <div class="vera">
                    <div class="verk" style="font-size:25px;color:#F0E68C; width:100%;height:30px; ">
                        <b>Select Seat Type</b>
                        <div class="ver">
                            <div class="verb">
                                <input type="radio" id="premium" name="seat_type" value="Premium">
                                <label for="premium"><b>Premium</b></label><br>
                                <input type="radio" id="regular" name="seat_type" value="Regular">
                                <label for="regular"><b>Regular</b></label><br> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="vera">
                </div>

                <div class="vera">
                    <div class="verk" style="font-size:25px; width:100%;height:30px; ">
                        <b style="font-size: 20px; padding-left:70px">Ticket Quantity</b><br>
                        <div class="ver">
                            <div class="verb">
                                <button style="margin-left: 70px; background-color: transparent; text-align: center; color: black; height: 35px; width: 30px; font-size: 30px;" type="button" onclick="decrement()">-</button>
                            </div>
                            <div class="verb" >
                                <input id="quantity" style="margin-left: 0px; background-color: white; opacity:0.4; text-align: center; color: black; height: 35px; width: 90px; font-size: 30px;" type="text" name="count" value="1">
                            </div>
                            <div class="verb">
                                <button style="margin-left: 0px; background-color: transparent; text-align: center; color: black; height: 35px; width: 30px; font-size: 30px;" type="button" onclick="increment()">+</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <input type="submit" name="login" value="Next">
        </form>
    </div>
    <script>
        function redirectToselother1() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother1.php';
        }
        function redirectToselother2() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother2.php';
        }
        function redirectToselother3() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother3.php';
        }
        function redirectToselother2a() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother2a.php';
        }
        function redirectToselother2b() {
            // Redirect to the selver3d.php page
            window.location.href = 'selother2b.php';
        }

        function decrement() {
            var quantity = document.getElementById('quantity');
            if (quantity.value > 1) {
                quantity.value--;
            }
        }

        function increment() {
            var quantity = document.getElementById('quantity');
            quantity.value++;
        }
    </script>
</body>
</html>
