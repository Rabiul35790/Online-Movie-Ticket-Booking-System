<?php include "db_conn.php"; ?>

<?php
session_start();

// Retrieve the booking code
if (isset($_SESSION['booking_code'])) {
    $booking_code = $_SESSION['booking_code'];
} else {
    $booking_code = generateRandomCode(6);
}

if (isset($_POST['login'])) {

    
        
            // Store values in the database
            $sql_insert = "INSERT INTO branch_tb (booking_code, branch) VALUES ('$booking_code', 'Purbachal')";
            if (mysqli_query($conn, $sql_insert)) {
                generateNextThreeDates();
                header("Location: selother.php");
                exit();
            } else {
                echo '<script>alert("Error in sending data to the database")</script>';
            }
       
}

// Add or modify the generateNextThreeDates function in selbranch.php

function generateNextThreeDates() {
    $dates = [];

    // Get today's date and time
    $now = new DateTime();

    // Define the day numbers for Wednesday, Thursday, and Friday
    $wednesday = 3;
    $thursday = 4;
    $friday = 5;

    // Calculate days until the next Wednesday, Thursday, and Friday
    $daysUntilNextWednesday = ($wednesday - (int)$now->format('N') + 7) % 7;
    $daysUntilNextThursday = ($thursday - (int)$now->format('N') + 7) % 7;
    $daysUntilNextFriday = ($friday - (int)$now->format('N') + 7) % 7;

    // Calculate the next Wednesday, Thursday, and Friday dates
    $nextWednesday = clone $now;
    $nextWednesday->modify("+$daysUntilNextWednesday days");

    $nextThursday = clone $now;
    $nextThursday->modify("+$daysUntilNextThursday days");

    $nextFriday = clone $now;
    $nextFriday->modify("+$daysUntilNextFriday days");

    // Check if the respective days have passed, then update them to the next week's date
    if ($daysUntilNextWednesday === 0) {
        $nextWednesday->modify('+7 days');
    }

    if ($daysUntilNextThursday === 0) {
        $nextThursday->modify('+7 days');
    }

    if ($daysUntilNextFriday === 0) {
        $nextFriday->modify('+7 days');
    }

    // Store the dates in session variables
    $_SESSION['date1'] = $nextWednesday->format('Y-m-d');
    $_SESSION['date2'] = $nextThursday->format('Y-m-d');
    $_SESSION['date3'] = $nextFriday->format('Y-m-d');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="branch.css">
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="first">
    <div class="magic-text"><b>CineMagic</b></div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>
        <div class="verh">
            <h3 class="another-text">Select Branch</h3>
        </div>
        <div class="ver">
            <div class="vera">
                <button type="button" class="button" onclick="redirectToselbranch1()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Banani CineMagic</button>
            </div>
                
            <div class="verb">
                <button type="button" class="button button1" onclick="redirectToselbranch2()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Purbachal CineMagic</button>
            </div>
        </div>
        <div class="ver">
            <div class="vera">
                <button type="button" class="button" onclick="redirectToselbranch3()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Mirpur-1 CineMagic</button>
            </div>
                
            <div class="verb">
                <button type="button" class="button" onclick="redirectToselbranch4()"><img src="uploads/loc.png" height= "25px" width="25px"><br>Gulshan CineMagic</button>
            </div>
        </div>
        
        <form method="POST">  
            
            <input type="submit" name="login" value="Next">
        </form>
    </div>
    <script>
        function redirectToselbranch1() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch1.php';
        }
        function redirectToselbranch2() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch2.php';
        }
        function redirectToselbranch3() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch3.php';
        }
        function redirectToselbranch4() {
            // Redirect to the selver3d.php page
            window.location.href = 'selbranch4.php';
        }
    </script>
</body>
</html>
