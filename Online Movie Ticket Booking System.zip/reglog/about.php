<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="about.css">
    <title>Movie Ticket Sales</title>
    
</head>
<body>
    <div class="first">
        <div class="title-section">
        <div class="magic-text"><b>CineMagic</b></div>
        </div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a class="logs" href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>

        <!-- Search bar placed in the title-section -->

        <div class="second">
            <main>
                <section class="about-section">
                    <h1>About Us</h1>
                    <p>Welcome to our Movie Ticket Booking System! We are passionate about bringing the best movie experiences to our customers.</p>
                    
                    <h2>Our Mission</h2>
                    <p>Our mission is to provide a convenient and user-friendly platform for movie enthusiasts to easily browse, select, and book movie tickets.</p>
                    
                    <h2>Why Choose Us?</h2>
                    <ul>
                        <li>Wide movie selection</li>
                        <li>Secure and hassle-free booking</li>
                        <li>Convenient payment options</li>
                        <li>Responsive customer support</li>
                        <!-- Add more points as needed -->
                    </ul>
                    
                    <h2>Team</h2>
                    <div class="team-section">
                        <div class="team-member">
                            <img src="uploads/traced-me.jpg" alt="Rabiul">
                            <p>Mohammad Rabiul Hasan</p>
                        </div>

                        <div class="team-member">
                            <img src="uploads/mridul.jpg" alt="Mridul">
                            <p>Mehedi Hasan Mridul</p>
                        </div>

                        <div class="team-member">
                            <img src="uploads/nayeem.jpg" alt="Nayeem">
                            <p>Abu Shaleh Mohammad Nayeem</p>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </div>
    <footer>
        &copy; 2024 CineMagic Movie Ticket Booking System. All Rights Reserved.
    </footer>
</body>
</html>
