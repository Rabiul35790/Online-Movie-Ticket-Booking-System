<?php include "db_conn.php"; ?>
<?php
session_start();

function generateRandomCode($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}

if (isset($_GET['generate_code'])) {
    $booking_code = generateRandomCode(6);
    $_SESSION['booking_code'] = $booking_code;

    // Redirect to selver.php with the generated booking code as a URL parameter
    header("Location: selver.php?booking_code=$booking_code");
    exit();
}

if (isset($_GET['search'])) {
    $search = $_GET['search'];

    $sql = "SELECT * FROM images WHERE movie_name LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div>";
            echo "<p>{$row['movie_name']}</p>";
            echo "<img src='uploads/{$row['image_url']}' width='220' height='300'>";
            echo "</div>";
        }
    } else {
        echo "No results found";
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="list.css">
    <link href='https://fonts.googleapis.com/css?family=Abel' rel='stylesheet'>
    <title>Movie Ticket Sales</title>
</head>
<body>
    <div class="first">
        <div class="title-section">
        <div class="magic-text"><b>CineMagic</b></div>
            <div class="search-form">
                <form action="search.php" method="GET">
                    <input type="text" placeholder="Search..." name="search">
                    <button type="submit">Search</button>
                </form>
            </div>
        </div>
        <div class="navbar">
            <div class="menu">
                <a href="home.php">Home</a>
                <a href="showtimes.php">Show Time</a>
                <a class="logs" href="movielist.php">Movie List</a>
                <a href="selver1.php">Ticket price</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact</a>
                
            </div>
            <a href="login.php" class="logout">Logout</a>
        </div>

        <!-- Search bar placed in the title-section -->

        <div class="second">
    <?php 
    $sql = "SELECT * FROM images ORDER BY id DESC LIMIT 4"; // Fetches the latest four images
    $res = mysqli_query($conn, $sql);

    if (mysqli_num_rows($res) > 0) {
        while ($images = mysqli_fetch_assoc($res)) {  ?>
            <div class="tabf">
                <div class="f">
                    <p class="another-text" style="font-family: 'Abel', sans-serif; font-size: 25px; font-style: normal; padding-left: 30px;"><?=$images['movie_name']?></p>
                    <div class="alb">
                        <img src="uploads/<?=$images['image_url']?>" width="220" height="280">
                    </div>
                    <div class="buy-bar">
                        <a href="movielist.php?generate_code=true" class="buy-button">Buy Ticket</a>
                    </div>
                </div>
            </div>
    <?php }} ?>
</div>


    </div>
</body>
</html>
